<!DOCTYPE html>
        <?php
        define("HOST","sql204.epizy.com");
    define("USERNAME", "epiz_26046265");
define("PASSWORD","9Ha5shvOlR");
define("DBNAME","epiz_26046265_qbreak");
        ?>