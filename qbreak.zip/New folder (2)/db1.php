<!DOCTYPE html>
        <?php
        define("HOST","localhost");
define("USERNAME", "root");
define("PASSWORD","");
define("DBNAME","trio");
        ?>